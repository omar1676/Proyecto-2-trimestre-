package competicion;

import clubes.Club;
import partido.Partido;

import java.util.Random;

public class Supercopa extends Competicion {

    private Club[] participantes;
    private int totalParticipantes;

    private Partido semi1;
    private Partido semi2;
    private Partido granFinal;

    private Club ganadorSemi1;
    private Club ganadorSemi2;
    private Club campeonSupercopa;

    private int faseActual; // 0: semis, 1: final, 2: terminada
    private Random rnd;

    public Supercopa(String nombre, Club[] clubes) {
        super(nombre);

        this.rnd = new Random();
        this.faseActual = 0;

        this.participantes = new Club[0];
        this.totalParticipantes = 0;

        if (clubes != null) {
            this.participantes = new Club[clubes.length];

            int i = 0;
            while (i < clubes.length) {
                if (clubes[i] != null) {
                    this.participantes[this.totalParticipantes] = clubes[i];
                    this.totalParticipantes++;
                }
                i++;
            }
        }
    }

    @Override
    public void generar() {

        if (isGenerada()) {
            System.out.println("Ya estaba generada: " + getNombre());
            return;
        }

        System.out.println("\n==========================================");
        System.out.println("GENERANDO: " + getNombre().toUpperCase());
        System.out.println("==========================================");

        if (totalParticipantes < 4) {
            System.out.println("Error: Se requieren 4 equipos.");
            setGenerada(true);
            setTerminada(true);
            return;
        }

        this.semi1 = new Partido(participantes[0], participantes[3]);
        this.semi2 = new Partido(participantes[1], participantes[2]);

        setGenerada(true);
        setTerminada(false);

        System.out.println("Semifinal 1: " + participantes[0].getNombre() + " vs " + participantes[3].getNombre());
        System.out.println("Semifinal 2: " + participantes[1].getNombre() + " vs " + participantes[2].getNombre());
        System.out.println("------------------------------------------");
    }

    public boolean simularRonda(Club seguido, boolean verEnDirectoSeguido) {

        if (!isGenerada()) generar();

        if (haTerminado()) {
            System.out.println("La competición ya ha finalizado.");
            return false;
        }

        if (faseActual == 0) {

            System.out.println("\n------------------------------------------");
            System.out.println("SEMIFINALES - " + getNombre().toUpperCase());
            System.out.println("------------------------------------------");

            boolean verS1 = false;
            boolean verS2 = false;

            if (verEnDirectoSeguido && seguido != null) {
                if (semi1 != null && semi1.participa(seguido)) verS1 = true;
                if (semi2 != null && semi2.participa(seguido)) verS2 = true;
            }

            this.ganadorSemi1 = jugarPartidoUnico(semi1, verS1);
            this.ganadorSemi2 = jugarPartidoUnico(semi2, verS2);

            System.out.println("\nRESULTADOS SEMIFINALES:");
            if (semi1 != null) System.out.println(" - " + semi1);
            if (semi2 != null) System.out.println(" - " + semi2);

            this.granFinal = new Partido(ganadorSemi1, ganadorSemi2);
            this.faseActual = 1;

            System.out.println("\nFinalistas: " + ganadorSemi1.getNombre() + " y " + ganadorSemi2.getNombre());
            return true;
        }

        if (faseActual == 1) {

            System.out.println("\n------------------------------------------");
            System.out.println("FINAL - " + getNombre().toUpperCase());
            System.out.println("------------------------------------------");

            boolean verF = false;
            if (verEnDirectoSeguido && seguido != null) {
                if (granFinal != null && granFinal.participa(seguido)) verF = true;
            }

            this.campeonSupercopa = jugarPartidoUnico(granFinal, verF);

            System.out.println("\nRESULTADO FINAL:");
            if (granFinal != null) System.out.println(" - " + granFinal);

            this.faseActual = 2;
            setTerminada(true);

            System.out.println("\n¡" + campeonSupercopa.getNombre().toUpperCase() + " ES EL CAMPEÓN!");
            System.out.println("------------------------------------------\n");
            return true;
        }

        return false;
    }

    @Override
    public boolean simularRonda(boolean verEnDirecto) {
        return simularRonda(null, verEnDirecto);
    }

    @Override
    public void mostrarUltimosResultados() {

        System.out.println("\n==========================================");
        System.out.println("RESULTADOS: " + getNombre().toUpperCase());
        System.out.println("==========================================");

        if (semi1 != null && semi1.isJugado()) System.out.println(" - Semifinal 1: " + semi1);
        if (semi2 != null && semi2.isJugado()) System.out.println(" - Semifinal 2: " + semi2);
        if (granFinal != null && granFinal.isJugado()) System.out.println(" - Final:       " + granFinal);

        System.out.println("==========================================\n");
    }

    @Override
    public boolean haTerminado() {
        return isTerminada();
    }

    // ✅ OBLIGATORIO por Competicion:
    // Devuelve los ganadores de la última "jornada" (aquí: última fase simulada).
    @Override
    public Club[] getGanadoresUltimaJornada() {

        Club[] ganadores = new Club[2];
        ganadores[0] = null;
        ganadores[1] = null;

        // Si aún no se ha jugado nada:
        if (faseActual == 0) {
            return ganadores;
        }

        // Si ya se jugaron semis (y estamos en final o terminado), devolvemos ganadores de semis:
        if (ganadorSemi1 != null) ganadores[0] = ganadorSemi1;
        if (ganadorSemi2 != null) ganadores[1] = ganadorSemi2;

        // Si terminó, el ganador real es el campeón (lo devolvemos en la primera posición)
        if (faseActual >= 2 && campeonSupercopa != null) {
            ganadores[0] = campeonSupercopa;
            ganadores[1] = null;
        }

        return ganadores;
    }

    public boolean sigueVivo(Club c) {

        if (c == null) return false;

        if (haTerminado()) {
            return c == campeonSupercopa;
        }

        if (faseActual == 0) return true;

        if (faseActual == 1) {
            if (c == ganadorSemi1) return true;
            if (c == ganadorSemi2) return true;
            return false;
        }

        return false;
    }

    private Club jugarPartidoUnico(Partido p, boolean directo) {

        if (p == null) return null;

        p.simular(directo);

        int gL = p.getGolesDelLocal();
        int gV = p.getGolesDelVisitante();

        if (gL > gV) return p.getEquipoLocal();
        if (gV > gL) return p.getEquipoVisitante();

        System.out.print("Empate (" + gL + "-" + gV + "). Penaltis... ");

        if (rnd.nextBoolean()) {
            System.out.println("Pasa " + p.getEquipoLocal().getNombre());
            return p.getEquipoLocal();
        } else {
            System.out.println("Pasa " + p.getEquipoVisitante().getNombre());
            return p.getEquipoVisitante();
        }
    }
}